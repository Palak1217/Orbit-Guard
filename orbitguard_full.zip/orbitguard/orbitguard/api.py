"""FastAPI server.  Run:  uvicorn orbitguard.api:app --reload"""
from __future__ import annotations

from typing import List, Optional

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .model import MODEL_PATH, RiskModel
from .orbit import propagate
from pathlib import Path

from fastapi.staticfiles import StaticFiles

from .service import assess_encounter, build_events, demo_scenario

app = FastAPI(title="OrbitGuard", version="0.1.0",
              description="AI space-debris collision early-warning & avoidance")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"],
                   allow_headers=["*"])

_model: Optional[RiskModel] = None


def get_model() -> RiskModel:
    global _model
    if _model is None:
        if not MODEL_PATH.exists():
            raise HTTPException(503, "Model not trained yet. Run: python train.py")
        _model = RiskModel.load()
    return _model


class State(BaseModel):
    r_km: List[float] = Field(..., min_length=3, max_length=3, description="ECI position")
    v_kms: List[float] = Field(..., min_length=3, max_length=3, description="ECI velocity")


class AssessRequest(BaseModel):
    satellite: State
    debris: State
    sigma_km: float = Field(0.3, gt=0, description="position uncertainty (1-sigma)")
    radius_m: float = Field(3.0, gt=0, description="combined hard-body radius")
    horizon_hours: float = Field(24.0, gt=0, le=72)
    safe_miss_km: float = Field(5.0, gt=0)


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": MODEL_PATH.exists()}


@app.post("/assess")
def assess(req: AssessRequest):
    sat = (np.array(req.satellite.r_km), np.array(req.satellite.v_kms))
    deb = (np.array(req.debris.r_km), np.array(req.debris.v_kms))
    try:
        return assess_encounter(get_model(), sat, deb, req.sigma_km, req.radius_m,
                                req.horizon_hours, req.safe_miss_km)
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.get("/demo")
def demo(seed: Optional[int] = None):
    """Random simulated encounter + full assessment (great for live demos)."""
    return demo_scenario(get_model(), seed)


_events_cache: dict = {}


@app.get("/events")
def events(n: int = 5, seed: int = 0, refresh: bool = False):
    """Simulated close-approach feed for the dashboard (cached per n/seed)."""
    key = (n, seed)
    if refresh or key not in _events_cache:
        _events_cache[key] = build_events(get_model(), n=max(2, min(n, 8)), seed=seed)
    return {"events": _events_cache[key]}


@app.get("/trajectory")
def trajectory(r_km: str, v_kms: str, hours: float = 3.0, step_s: float = 60.0):
    """Ground-truth path for plotting, e.g. r_km=7000,0,0&v_kms=0,7.5,0"""
    try:
        r = np.array([float(x) for x in r_km.split(",")])
        v = np.array([float(x) for x in v_kms.split(",")])
        t = np.arange(0, hours * 3600, step_s)
        pos, _ = propagate(r, v, t)
    except Exception as e:
        raise HTTPException(422, str(e))
    return {"t_s": t.tolist(), "positions_km": pos.tolist()}


# Serve the dashboard from the same server (must be mounted last).
_FRONTEND = Path(__file__).resolve().parent.parent / "frontend"
if _FRONTEND.exists():
    app.mount("/", StaticFiles(directory=_FRONTEND, html=True), name="frontend")
