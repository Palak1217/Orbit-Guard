"""ML risk model: learns collision risk from simulated, noisy close approaches."""
from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import (classification_report, mean_absolute_error,
                             roc_auc_score)
from sklearn.model_selection import train_test_split

from .simulate import FEATURES, risk_level

MODEL_PATH = Path(__file__).resolve().parent.parent / "models" / "orbitguard_model.joblib"


class RiskModel:
    def __init__(self):
        self.reg = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.07,
                                                 random_state=0)
        self.clf = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.07,
                                                  random_state=0)

    def fit(self, df):
        X, y_reg, y_clf = df[FEATURES], df["log10_pc"], df["high_risk"]
        Xtr, Xte, ytr, yte, ctr, cte = train_test_split(
            X, y_reg, y_clf, test_size=0.2, random_state=1, stratify=y_clf)
        self.reg.fit(Xtr, ytr)
        self.clf.fit(Xtr, ctr)

        p = self.clf.predict_proba(Xte)[:, 1]
        pred = (p >= 0.3).astype(int)  # lower threshold: missing a collision is worse
        metrics = {
            "log10_pc_MAE": float(mean_absolute_error(yte, self.reg.predict(Xte))),
            "high_risk_AUC": float(roc_auc_score(cte, p)),
            "report": classification_report(cte, pred, digits=3),
            "n_train": len(Xtr), "n_test": len(Xte),
        }
        return metrics

    def assess(self, features: dict) -> dict:
        x = pd.DataFrame([{f: features[f] for f in FEATURES}])
        log_pc = float(self.reg.predict(x)[0])
        p_high = float(self.clf.predict_proba(x)[0, 1])
        pc = 10 ** log_pc
        return {
            "predicted_pc": pc,
            "prob_high_risk": p_high,
            "risk_level": risk_level(pc),
            "risk_score": float(np.clip((log_pc + 12) / 10, 0, 1) * 100),  # 0-100 for the UI
        }

    def save(self, path: Path = MODEL_PATH):
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, path)

    @staticmethod
    def load(path: Path = MODEL_PATH) -> "RiskModel":
        return joblib.load(path)
