"""OrbitGuard - AI space debris avoidance backend."""
