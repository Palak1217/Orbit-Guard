"""Close-approach (conjunction) detection between two objects."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .orbit import propagate, altitude


@dataclass
class Encounter:
    tca: float  # seconds from epoch to time of closest approach
    miss_km: float
    rel_speed_kms: float
    approach_angle_deg: float  # angle between the two velocity vectors
    sat_alt_km: float
    deb_alt_km: float
    rel_pos: np.ndarray
    rel_vel: np.ndarray


def _distance_series(sat, deb, times):
    rs, vs = propagate(*sat, times)
    rd, vd = propagate(*deb, times)
    rel = rd - rs
    return np.linalg.norm(rel, axis=1), rs, vs, rd, vd


def find_closest_approach(sat, deb, horizon_s=6 * 3600.0, coarse_dt=10.0,
                          t_start=0.0) -> Encounter:
    """sat / deb are (r0, v0) tuples. Coarse scan, then a fine local refinement."""
    times = np.arange(t_start, t_start + horizon_s, coarse_dt)
    d, *_ = _distance_series(sat, deb, times)
    i = int(np.argmin(d))
    lo = times[max(i - 1, 0)]
    hi = times[min(i + 1, len(times) - 1)]

    fine = np.linspace(lo, hi, 801)
    d2, rs, vs, rd, vd = _distance_series(sat, deb, fine)
    j = int(np.argmin(d2))

    vrel = vd[j] - vs[j]
    cosang = float(vs[j] @ vd[j] / (np.linalg.norm(vs[j]) * np.linalg.norm(vd[j])))
    return Encounter(
        tca=float(fine[j]),
        miss_km=float(d2[j]),
        rel_speed_kms=float(np.linalg.norm(vrel)),
        approach_angle_deg=float(np.degrees(np.arccos(np.clip(cosang, -1, 1)))),
        sat_alt_km=altitude(rs[j]),
        deb_alt_km=altitude(rd[j]),
        rel_pos=rd[j] - rs[j],
        rel_vel=vrel,
    )


def miss_distance_near(sat, deb, tca, window_s=600.0, n=1201) -> float:
    """Minimum separation in a window around a known TCA (used after a manoeuvre)."""
    times = np.linspace(tca - window_s, tca + window_s, n)
    d, *_ = _distance_series(sat, deb, times)
    return float(d.min())
