"""Synthetic close-approach scenario generator (training data for the ML model).

Each scenario: a satellite in LEO plus a piece of debris that is *constructed* to
pass near it at a chosen time. The tracker only sees a NOISY estimate of the miss
distance, while the label comes from the TRUE geometry. That gap is exactly what
the ML model has to learn to handle.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .orbit import R_EARTH, kepler_to_rv, propagate, circular_speed
from .conjunction import find_closest_approach

FEATURES = [
    "miss_km", "rel_speed_kms", "tca_hours", "sigma_km", "radius_m",
    "approach_angle_deg", "alt_diff_km", "sat_alt_km",
]


def pc_2d(miss_km, sigma_km, radius_m):
    """Simplified 2-D probability of collision (isotropic Gaussian uncertainty)."""
    R = radius_m / 1000.0
    return (R**2 / (2 * sigma_km**2)) * np.exp(-(miss_km**2) / (2 * sigma_km**2))


def risk_level(pc: float) -> str:
    if pc >= 1e-4:
        return "HIGH"
    if pc >= 1e-6:
        return "MEDIUM"
    return "LOW"


def random_satellite(rng):
    alt = rng.uniform(400, 1200)
    a = R_EARTH + alt
    e = rng.uniform(0, 0.01)
    inc = np.radians(rng.uniform(0, 100))
    return kepler_to_rv(a, e, inc, rng.uniform(0, 2 * np.pi),
                        rng.uniform(0, 2 * np.pi), rng.uniform(0, 2 * np.pi))


def make_scenario(rng, horizon_h=6.0):
    sat = random_satellite(rng)
    tca = rng.uniform(0.3, horizon_h) * 3600.0

    rs, vs = propagate(*sat, [tca])
    rs, vs = rs[0], vs[0]

    # Debris at TCA: satellite position + miss vector, with a random relative velocity
    miss_true = float(10 ** rng.uniform(-2, 1.3))  # 10 m .. 20 km (log-uniform)
    d = rng.normal(size=3)
    d /= np.linalg.norm(d)
    r_deb = rs + miss_true * d

    # Debris velocity: near-circular orbit at the encounter point (flight-path angle
    # within a few degrees) with a random heading => crossing angles 0..180 deg.
    r_hat = r_deb / np.linalg.norm(r_deb)
    ref = np.array([0.0, 0.0, 1.0]) if abs(r_hat[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    e1 = np.cross(r_hat, ref)
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(r_hat, e1)
    psi = rng.uniform(0, 2 * np.pi)
    gamma = np.radians(rng.normal(0, 1.5))
    horiz = np.cos(psi) * e1 + np.sin(psi) * e2
    v_dir = np.cos(gamma) * horiz + np.sin(gamma) * r_hat
    v_deb = circular_speed(np.linalg.norm(r_deb)) * v_dir

    deb0_r, deb0_v = propagate(r_deb, v_deb, [-tca])
    deb = (deb0_r[0], deb0_v[0])
    return sat, deb, miss_true


def generate_dataset(n=5000, seed=42, verbose=False) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    attempts = 0
    while len(rows) < n and attempts < n * 3:
        attempts += 1
        try:
            sat, deb, _ = make_scenario(rng)
            enc = find_closest_approach(sat, deb)
        except ValueError:  # unbound debris orbit, skip
            continue

        sigma = float(10 ** rng.uniform(-1.5, 0.5))   # 30 m .. 3 km position uncertainty
        radius = float(10 ** rng.uniform(0, 1.0))     # combined hard-body radius 1..10 m
        obs_miss = abs(enc.miss_km + rng.normal(0, sigma))  # what the tracker "sees"

        pc = float(pc_2d(enc.miss_km, sigma, radius))   # truth label
        rows.append({
            "miss_km": obs_miss,
            "rel_speed_kms": enc.rel_speed_kms,
            "tca_hours": enc.tca / 3600.0,
            "sigma_km": sigma,
            "radius_m": radius,
            "approach_angle_deg": enc.approach_angle_deg,
            "alt_diff_km": abs(enc.sat_alt_km - enc.deb_alt_km),
            "sat_alt_km": enc.sat_alt_km,
            "true_miss_km": enc.miss_km,
            "pc": pc,
            "log10_pc": float(np.log10(max(pc, 1e-15))),
            "high_risk": int(pc >= 1e-4),
        })
        if verbose and len(rows) % 500 == 0:
            print(f"  generated {len(rows)}/{n}")
    return pd.DataFrame(rows)
