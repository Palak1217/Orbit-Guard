"""High-level pipeline: Data -> Prediction -> Risk -> Decision -> Maneuver."""
from __future__ import annotations

import numpy as np

from .conjunction import find_closest_approach
from .maneuver import plan_maneuver
from .model import RiskModel
from .simulate import FEATURES, make_scenario, pc_2d, risk_level


def assess_encounter(model: RiskModel, sat, deb, sigma_km=0.3, radius_m=3.0,
                     horizon_h=24.0, safe_miss_km=5.0, plan=True):
    enc = find_closest_approach(sat, deb, horizon_s=horizon_h * 3600.0, coarse_dt=10.0)
    feats = {
        "miss_km": enc.miss_km,
        "rel_speed_kms": enc.rel_speed_kms,
        "tca_hours": enc.tca / 3600.0,
        "sigma_km": sigma_km,
        "radius_m": radius_m,
        "approach_angle_deg": enc.approach_angle_deg,
        "alt_diff_km": abs(enc.sat_alt_km - enc.deb_alt_km),
        "sat_alt_km": enc.sat_alt_km,
    }
    ml = model.assess(feats)
    physics_pc = float(pc_2d(enc.miss_km, sigma_km, radius_m))

    result = {
        "encounter": {
            "tca_seconds": enc.tca, "tca_hours": enc.tca / 3600.0,
            "miss_distance_km": enc.miss_km,
            "relative_speed_kms": enc.rel_speed_kms,
            "approach_angle_deg": enc.approach_angle_deg,
        },
        "risk": {**ml, "physics_pc": physics_pc,
                 "physics_level": risk_level(physics_pc)},
        "decision": "NO ACTION" if ml["risk_level"] == "LOW" else
                    ("MONITOR" if ml["risk_level"] == "MEDIUM" else "MANEUVER"),
        "maneuver": None,
    }
    if plan and ml["risk_level"] != "LOW":
        m = plan_maneuver(sat, deb, enc.tca, sigma_km, radius_m,
                          safe_miss_km=safe_miss_km)
        m.pop("candidates", None)  # keep API responses small
        result["maneuver"] = m
    return result


SAT_NAMES = ["ORBITGUARD-01", "AURORA-12", "TERRA-SCAN-03", "NEXUS-COMM-4", "HORIZON-9"]
_TONES = [(1e-3, "Critical", "critical"), (1e-4, "High", "high"),
          (1e-6, "Medium", "medium"), (0.0, "Low", "low")]


def _tone(pc):
    for thr, label, tone in _TONES:
        if pc >= thr:
            return label, tone


def _fmt_km(km):
    return f"{km:.3f} km" if km < 0.1 else f"{km:.2f} km"


def _fmt_pct(pc):
    pct = pc * 100
    return f"{pct:.2f}%" if pct >= 0.01 else f"{pct:.1e}%"


def _fmt_time(hours):
    h = int(hours)
    return f"{h:02d}h {int((hours - h) * 60):02d}m"


def _score(pc):
    return round(float(np.clip((np.log10(max(pc, 1e-15)) + 12) / 10, 0, 1)) * 100)


def build_events(model: RiskModel, n=5, pool=30, seed=0):
    """Simulate a pool of encounters, keep n spread from riskiest to safest, and
    return them in the shape the frontend renders (assessment + manoeuvre options)."""
    from .maneuver import plan_maneuver, summarize_options

    scored = []
    for i in range(pool):
        s = seed * 1000 + i
        rng = np.random.default_rng(s)
        sat, deb, _ = make_scenario(rng)
        try:
            res = assess_encounter(model, sat, deb, sigma_km=0.3, radius_m=3.0, plan=False)
        except ValueError:
            continue
        scored.append((res["risk"]["predicted_pc"], s, sat, deb, res))
    scored.sort(key=lambda x: -x[0])
    idx = np.unique(np.linspace(0, len(scored) - 1, n).round().astype(int))

    events = []
    for k, j in enumerate(idx):
        pc, s, sat, deb, res = scored[j]
        enc = res["encounter"]
        plan = plan_maneuver(sat, deb, enc["tca_seconds"], 0.3, 3.0)
        opts = []
        for letter, c in zip("ABC", summarize_options(plan)):
            lvl, _ = _tone(c["new_pc"])[0], None
            dv = abs(c["delta_v_ms"])
            opts.append({
                "id": letter,
                "dv": f"{dv:.2f} m/s",
                "distance": _fmt_km(c["new_miss_km"]),
                "new_miss_km": c["new_miss_km"],
                "risk": "Very Low" if c["new_pc"] < 1e-8 else lvl,
                "risk_score": _score(c["new_pc"]),
                "fuel": "Minimal" if dv < 0.3 else "Low" if dv < 1.0 else "Moderate",
                "direction": c["direction"],
                "burn_min": round(c["burn_time_before_tca_min"]),
                "burn_dir": f'{"+" if c["delta_v_ms"] > 0 else "-"}{dv:.2f} m/s {c["direction"]}',
            })
        label, tone = _tone(pc)
        events.append({
            "a": SAT_NAMES[k % len(SAT_NAMES)],
            "b": f"DEBRIS-{10000 + (s * 7919) % 90000}",
            "time": _fmt_time(enc["tca_hours"]),
            "distance": _fmt_km(enc["miss_distance_km"]),
            "velocity": f'{enc["relative_speed_kms"]:.1f} km/s',
            "probability": _fmt_pct(pc),
            "pc": pc,
            "risk": label, "tone": tone,
            "score": _score(pc),
            "decision": res["decision"],
            "ml_prob_high_risk": res["risk"]["prob_high_risk"],
            "options": opts,
            "recommended": plan["recommended"],
        })
    return events


def demo_scenario(model: RiskModel, seed=None):
    rng = np.random.default_rng(seed)
    sat, deb, _ = make_scenario(rng)
    out = assess_encounter(model, sat, deb, sigma_km=0.3, radius_m=3.0)
    out["scenario"] = {
        "sat": {"r_km": sat[0].tolist(), "v_kms": sat[1].tolist()},
        "debris": {"r_km": deb[0].tolist(), "v_kms": deb[1].tolist()},
    }
    return out
