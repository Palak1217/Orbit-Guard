"""Two-body orbit propagation (vectorised, singularity-free).

Uses the classical f & g functions with the eccentric-anomaly difference, so it
works for circular, equatorial and elliptical orbits without converting to
Keplerian angles. Units: km, km/s, seconds.
"""
from __future__ import annotations

import numpy as np

MU = 398600.4418  # km^3/s^2, Earth's gravitational parameter
R_EARTH = 6378.137  # km


def circular_speed(r: float) -> float:
    return float(np.sqrt(MU / r))


def propagate(r0, v0, times):
    """Propagate state (r0, v0) to every t in `times` (seconds, may be negative).

    Returns (positions[N,3], velocities[N,3]).
    """
    r0 = np.asarray(r0, dtype=float)
    v0 = np.asarray(v0, dtype=float)
    t = np.atleast_1d(np.asarray(times, dtype=float))

    r0n = np.linalg.norm(r0)
    v2 = float(v0 @ v0)
    a = 1.0 / (2.0 / r0n - v2 / MU)
    if a <= 0:
        raise ValueError("Only bound (elliptical) orbits are supported")
    n = np.sqrt(MU / a**3)
    sigma0 = float(r0 @ v0) / np.sqrt(MU)
    sqa = np.sqrt(a)

    M = n * t
    x = M.copy()  # initial guess for dE
    for _ in range(20):  # Newton iterations on the universal Kepler equation
        s, c = np.sin(x), np.cos(x)
        F = x + (sigma0 / sqa) * (1 - c) - (1 - r0n / a) * s - M
        dF = 1 + (sigma0 / sqa) * s - (1 - r0n / a) * c
        x = x - F / dF

    s, c = np.sin(x), np.cos(x)
    f = 1 - (a / r0n) * (1 - c)
    g = t - np.sqrt(a**3 / MU) * (x - s)
    r = f[:, None] * r0 + g[:, None] * v0
    rn = np.linalg.norm(r, axis=1)
    fdot = -np.sqrt(MU * a) / (rn * r0n) * s
    gdot = 1 - (a / rn) * (1 - c)
    v = fdot[:, None] * r0 + gdot[:, None] * v0
    return r, v


def altitude(r) -> float:
    return float(np.linalg.norm(r) - R_EARTH)


def orbital_period(r0, v0) -> float:
    r0n = np.linalg.norm(r0)
    a = 1.0 / (2.0 / r0n - float(np.dot(v0, v0)) / MU)
    return float(2 * np.pi * np.sqrt(a**3 / MU))


def kepler_to_rv(a, e, inc, raan, argp, nu):
    """Classical elements (km, rad) -> ECI state vector."""
    p = a * (1 - e**2)
    r_pf = (p / (1 + e * np.cos(nu))) * np.array([np.cos(nu), np.sin(nu), 0.0])
    v_pf = np.sqrt(MU / p) * np.array([-np.sin(nu), e + np.cos(nu), 0.0])

    cO, sO = np.cos(raan), np.sin(raan)
    ci, si = np.cos(inc), np.sin(inc)
    cw, sw = np.cos(argp), np.sin(argp)
    R = np.array([
        [cO * cw - sO * sw * ci, -cO * sw - sO * cw * ci, sO * si],
        [sO * cw + cO * sw * ci, -sO * sw + cO * cw * ci, -cO * si],
        [sw * si, cw * si, ci],
    ])
    return R @ r_pf, R @ v_pf


def rtn_basis(r, v):
    """Radial / Transverse (along-track) / Normal unit vectors."""
    r_hat = r / np.linalg.norm(r)
    h = np.cross(r, v)
    n_hat = h / np.linalg.norm(h)
    t_hat = np.cross(n_hat, r_hat)
    return r_hat, t_hat, n_hat
