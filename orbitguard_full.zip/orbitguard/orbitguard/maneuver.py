"""Avoidance manoeuvre planner.

Searches impulsive burns (along-track / radial / normal) at several lead times
before TCA, re-propagates the satellite, and picks the cheapest burn that pushes
the predicted miss distance past a safety threshold.
"""
from __future__ import annotations

import itertools

import numpy as np

from .conjunction import miss_distance_near
from .orbit import propagate, rtn_basis, orbital_period
from .simulate import pc_2d


def _apply_burn(sat, t_burn, dv_rtn):
    r, v = propagate(*sat, [t_burn])
    r, v = r[0], v[0]
    rh, th, nh = rtn_basis(r, v)
    dv = dv_rtn[0] * rh + dv_rtn[1] * th + dv_rtn[2] * nh  # m/s -> km/s below
    return r, v + dv / 1000.0


def plan_maneuver(sat, deb, tca, sigma_km, radius_m, safe_miss_km=5.0,
                  max_dv_ms=2.0, predicted_pc=None):
    """Return the best manoeuvre plan (or None if the encounter is already safe)."""
    period = orbital_period(*sat)
    lead_times = [0.25 * period, 0.5 * period, 1.0 * period, 1.5 * period]
    lead_times = [lt for lt in lead_times if tca - lt > 60]  # burn must be in the future
    if not lead_times:  # very short warning: burn as early as we still can
        lead_times = [f * tca for f in (0.5, 0.75, 0.95) if f * tca > 30]
    if not lead_times:
        raise ValueError("Encounter too imminent to plan a manoeuvre")
    dv_levels = [0.05, 0.1, 0.2, 0.4, 0.8, 1.5]
    axes = {"along-track": 1, "radial": 0, "normal": 2}

    candidates = []
    for lead, mag, (axis_name, axis_idx), sign in itertools.product(
            lead_times, dv_levels, axes.items(), (+1, -1)):
        if mag > max_dv_ms:
            continue
        dv = [0.0, 0.0, 0.0]
        dv[axis_idx] = sign * mag
        r_b, v_b = _apply_burn(sat, tca - lead, dv)
        # state after the burn, expressed at the burn epoch
        new_sat = (r_b, v_b)
        # shift deb timeline so both are measured from the burn epoch
        d_r, d_v = propagate(*deb, [tca - lead])
        new_deb = (d_r[0], d_v[0])
        miss = miss_distance_near(new_sat, new_deb, lead, window_s=600.0)
        candidates.append({
            "burn_time_before_tca_min": lead / 60.0,
            "direction": axis_name,
            "delta_v_ms": sign * mag,
            "new_miss_km": miss,
            "new_pc": float(pc_2d(miss, sigma_km, radius_m)),
            "safe": miss >= safe_miss_km,
        })

    safe = [c for c in candidates if c["safe"]]
    pool = safe if safe else candidates
    # cheapest safe burn; otherwise the one that opens the most distance
    best = (min(pool, key=lambda c: (abs(c["delta_v_ms"]), -c["new_miss_km"]))
            if safe else max(pool, key=lambda c: c["new_miss_km"]))
    top = sorted(pool, key=lambda c: abs(c["delta_v_ms"]))[:5] if safe else \
        sorted(pool, key=lambda c: -c["new_miss_km"])[:5]
    return {"recommended": best, "alternatives": top, "n_evaluated": len(candidates),
            "meets_safety_threshold": bool(safe), "candidates": candidates}


def summarize_options(plan, n=3):
    """Pick up to n distinct delta-v levels (best miss distance at each) for the UI."""
    by_dv = {}
    for c in plan["candidates"]:
        k = round(abs(c["delta_v_ms"]), 3)
        if k not in by_dv or c["new_miss_km"] > by_dv[k]["new_miss_km"]:
            by_dv[k] = c
    levels = sorted(by_dv)
    safe_levels = [k for k in levels if by_dv[k]["safe"]]
    chosen = (safe_levels or levels)[:n]
    if len(chosen) < n:  # pad with larger burns so the user can compare
        chosen += [k for k in levels if k not in chosen][: n - len(chosen)]
    return [by_dv[k] for k in sorted(chosen)]
