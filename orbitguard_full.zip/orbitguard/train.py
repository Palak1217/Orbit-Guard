"""Generate simulated close approaches and train the OrbitGuard risk model.

    python train.py              # 4000 scenarios
    python train.py --n 10000
"""
import argparse
import time

from orbitguard.model import RiskModel, MODEL_PATH
from orbitguard.simulate import generate_dataset

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=4000)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    t0 = time.time()
    print(f"Simulating {args.n} close-approach scenarios...")
    df = generate_dataset(args.n, seed=args.seed, verbose=True)
    df.to_csv("training_data.csv", index=False)
    print(f"  done in {time.time() - t0:.1f}s | high-risk share: {df.high_risk.mean():.1%}")

    model = RiskModel()
    m = model.fit(df)
    print(f"\nlog10(Pc) MAE: {m['log10_pc_MAE']:.3f} | high-risk AUC: {m['high_risk_AUC']:.3f}")
    print(m["report"])
    model.save()
    print(f"Saved model -> {MODEL_PATH}")
