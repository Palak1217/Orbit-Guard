# OrbitGuard backend

Data -> Prediction -> Risk -> Decision -> Maneuver

```bash
pip install -r requirements.txt
python train.py --n 5000            # simulate scenarios + train ML model
uvicorn orbitguard.api:app --reload
```

Open **http://127.0.0.1:8000** for the dashboard (served from `frontend/`), or
**/docs** for the API. The dashboard loads real model output from `GET /events`;
if the backend is unreachable it falls back to built-in demo data.

| File | Role |
|---|---|
| `orbitguard/orbit.py` | Two-body propagation (f & g functions), RTN frame |
| `orbitguard/conjunction.py` | Finds time of closest approach, miss distance, relative speed |
| `orbitguard/simulate.py` | Synthetic encounter generator + physics collision probability (Pc) |
| `orbitguard/model.py` | Gradient-boosting regressor (log10 Pc) + high-risk classifier |
| `orbitguard/maneuver.py` | Searches burns (direction, size, timing) for the cheapest safe one |
| `orbitguard/service.py` | End-to-end pipeline |
| `orbitguard/api.py` | FastAPI: `/events`, `/demo`, `/assess`, `/trajectory`, `/health` + serves `frontend/` |
| `frontend/` | Dashboard (HTML/CSS/JS), wired to `/events` |

Limits (say these in your pitch): two-body physics only (no J2/drag), simplified 2-D Pc,
simulated data. Swap in SGP4 + real TLEs from CelesTrak/Space-Track as a next step.
